#!/bin/sh
# ============================================================================
# mgu-app-install.sh - install custom OAP apps on a BMW MGU (ID7) head unit.
# Runs ON the unit (or the QEMU VM) as root. Same script for both.
#
#   sh mgu-app-install.sh install <app@ver.mgu> [...]   install or update
#   sh mgu-app-install.sh verify <app@ver.mgu> [...]    would the unit accept it? (dry run of
#                                                       step 4 below; nothing is changed)
#   sh mgu-app-install.sh uninstall <app-id> [...]
#   sh mgu-app-install.sh list                          installed apps + state
#   sh mgu-app-install.sh status <app-id>               details + recent log
#   sh mgu-app-install.sh restore [backup-dir]          undo (newest backup)
#   sh mgu-app-install.sh apply                         restart the app platform
#   sh mgu-app-install.sh patch [--persist]             enable the custom-app
#                                                       provisioning hook (see below)
#   sh mgu-app-install.sh unpatch                       back to stock MainApp
#   sh mgu-app-install.sh renderd [--persist]           install / start the GPU renderer
#                                                       (mgu-renderd next to this script);
#                                                       --persist: with in-page drawing too
#                                                       (NO_EMBED=1: without)
#   sh mgu-app-install.sh renderd-remove                stop and remove it
#   sh mgu-app-install.sh renderd-embed [--now]         (re)make the HMI page template for in-page
#                                                       drawing (renderd --persist does it too); from
#                                                       the next head-unit start (--now: restart the
#                                                       HMI now, VM / bench only)
#   sh mgu-app-install.sh renderd-embed-remove [--now]  take the page template out again
#   sh mgu-app-install.sh inputgate [--now]             let full-screen apps (Doom) have the iDrive
#                                                       controller (mgu-inputgate.so in the HMI).
#                                                       Loads at the next head-unit start; a boot
#                                                       guard leaves it out if the HMI fails with it.
#                                                       --now: restart the HMI now (VM / bench only:
#                                                       on a car an HMI restart reboots the unit)
#   sh mgu-app-install.sh inputgate-remove [--now]      take it out again (next start / --now)
#   sh mgu-app-install.sh inputgate-status              loaded / set up / left out
#
# Options (env):  NO_RESTART=1  don't restart oapcontroller after changes
#                 BACKUP_ROOT=<dir>   where backups go (default next to script)
#
# What "install" does - the same layout MainApp creates for BMW's own apps
# (checked against M Laptimer on this firmware, /var/opt/public/oap/oap_12219):
#   1. backs up the app registry (uids.txt + data/apps/*.json) first
#   2. picks a free service uid from the TOP of MainApp's range (12450 down),
#      or reuses the app's uid on update. MainApp gives its own apps the LOWEST
#      free uid (12203 up) from a list it only reloads on restart, so counting
#      up from the bottom could hand both the same uid (BMW app overwrites ours)
#   3. unpacks to /var/opt/public/oap/oap_<uid>/{source,rhmiData}, links the
#      platform's native node modules, creates data/kvs/share/security
#   4. generates someipInterfaces/ + acl.json from the app's manifest.json with
#      BMW's OWN generator (extracted from MainApp) and the unit's catalog
#   5. sets owner 12201:<uid>, modes and the POSIX ACLs that let the HMI read
#      the icon/graphics (without them the tile never appears)
#   6. registers it as a PREINSTALLED, manually-started app (the same entry the
#      stock M Laptimer has), so MainApp's provisioning reconcile keeps it
#   7. lists it in oap_12201/data/custom_apps.json and restarts oapcontroller
#      so MainApp picks it up (HMI reloads once)
# Nothing outside /var/opt/public/oap is written by install/uninstall.
#
# The provisioning hook ("patch"): MainApp only shows apps that BMW's signed
# provisioning data (Telematics, ProvSigned.xml) lists as enabled. Custom apps
# are not in it, so MainApp hides them. "patch" builds a copy of MainApp's
# main.js with one fallback added - "if the provisioning data for an app is
# empty, use its entry from custom_apps.json" - and BIND-MOUNTS it over the
# stock file. Stock main.js on the read-only rootfs is not changed; a reboot
# returns to stock unless --persist (a systemd drop-in that re-applies the
# bind mount when oapcontroller starts). "unpatch" undoes both.
# ============================================================================
set -u

OAP=/var/opt/public/oap
MAIN=$OAP/oap_12201
UIDS=$MAIN/security/uids.txt
REG=$MAIN/data/apps
CUSTOM=$MAIN/data/custom_apps.json
CATALOG=${CATALOG:-/etc/oap/someip/someip-interfaces.json}   # the unit's SOME/IP interface catalog
MAINJS=/usr/lib/oap-mainapp/src/main.js
PATCH_DIR=$OAP/_mgu_custom
DROPIN=/etc/systemd/system/oapcontroller.service.d/50-mgu-custom-apps.conf
NODE=${NODE:-/usr/bin/node}
# GPU renderer (kit/renderd): apps draw through it at 60 fps when it runs, else in software
RENDERD_DIR=/var/opt/mgu-renderd
RENDERD_UNIT=mgu-renderd.service
RENDERD_FILES="foreground_gate.js hmi_template.js mgu-render-hmi.sh mgu-render-hmi-guard.sh LICENSE LICENSE.mgu-renderd"
# in-page drawing: the page template's unit and its files in /run (apart from mgu-store's mgu-render)
EMBED_UNIT=mgu-renderd-hmi.service
EMBED_RUN=/run/mgu-renderd-hmi
# display-bridge (mgu-apps) stands down while this renderer is installed: one page template, one embed provider
DBR_UNITS="display-bridge.socket display-bridge.service display-bridge-hmi.service"
DBR_DROPIN=mgu-renderd.conf
# controller gate for full-screen apps (kit/renderd/inputgate): preloaded into the HMI
GATE_SO=$RENDERD_DIR/mgu-inputgate.so
GATE_DROPIN_NAME=hmi.service.d/zz-mgu-inputgate.conf
APP_GID=12202          # tm_oap_app: every app has it, so they may use the renderer's socket
# MainApp's usableUidsAndGids is 12203..12450 and it allocates from the bottom;
# custom apps are allocated from the top so the two never meet.
FIRST_UID=12450
LAST_UID=12351
SELF_DIR=$(cd "$(dirname "$0")" && pwd)
BACKUP_ROOT=${BACKUP_ROOT:-$SELF_DIR/backups}
TMP=${TMPDIR:-/tmp}/mgu-app-install.$$
CHANGED=0
NEED_RESTART=0
DONE_RESTART=0         # install: the apps already installed need the restart (an error later says so)

say()  { echo "[mgu-app] $*"; }
warn() { echo "[mgu-app] WARNING: $*" >&2; }
die()  {
    echo "[mgu-app] ERROR: $*" >&2; rm -rf "$TMP"
    # not restarted here: the app that failed may be an update half replaced (it would start broken)
    [ $DONE_RESTART = 1 ] && echo "[mgu-app] the apps installed before this error are kept; they start after: sh $0 apply" >&2
    exit 1
}

[ "$(id -u)" = 0 ] || die "run as root"
[ -d "$MAIN" ] || die "$MAIN not found - is this an MGU with the OAP platform (and /var/opt/public mounted)?"
[ -f "$UIDS" ] || die "$UIDS missing"
[ -x "$NODE" ] || die "node not found at $NODE"

uid_of() {      # app id -> uid from uids.txt
    sed -n "s/^\([0-9]*\)=$1\$/\1/p" "$UIDS" | head -n 1
}
app_of() {      # uid -> app id
    sed -n "s/^$1=\(.*\)\$/\1/p" "$UIDS" | head -n 1
}
# is_ours <id> <uid>: an app this tool installed (listed in custom_apps.json or built with
# the kit). Not decided by uid: MainApp can give its own apps any uid in the range too.
is_ours() {
    [ -f "$OAP/oap_$2/source/javascript/kit/app-spec.json" ] && return 0
    [ -f "$CUSTOM" ] && grep -q "\"$1\"" "$CUSTOM"
}
free_uid() {
    u=$FIRST_UID
    while [ $u -ge $LAST_UID ]; do
        if [ -z "$(app_of $u)" ] && [ ! -e "$OAP/oap_$u" ]; then echo $u; return 0; fi
        u=$((u - 1))
    done
    return 1
}

backup() {
    ts=$(date +%Y%m%d-%H%M%S)
    B=$BACKUP_ROOT/$ts
    mkdir -p "$B" || die "cannot create backup dir $B"
    cp -p "$UIDS" "$B/uids.txt" || die "cannot back up $UIDS - nothing changed"
    tar czf "$B/registry.tgz" -C "$MAIN/data" apps || die "cannot back up $REG - nothing changed"
    [ -f "$CUSTOM" ] && cp -p "$CUSTOM" "$B/custom_apps.json"
    echo "$B" > "$BACKUP_ROOT/latest"
    say "backup: $B"
}

ensure_newline() {   # the stock uids.txt has no trailing newline
    [ -s "$1" ] && [ -n "$(tail -c1 "$1")" ] && echo >> "$1"
    return 0
}

set_acls() {
    top=$1; u=$2
    # same grants as BMW's apps (M Laptimer): HMI must traverse the app dir and
    # read rhmiData; the rest stays private to the app and MainApp
    setfacl -m g:hmi_resourceaccess:r-x,g:nav_oap:--x,g:sps_necema:r-x,g:dumm_oap:--x "$top" 2>/dev/null \
        || setfacl -m g:5001:r-x "$top" || warn "setfacl failed on $top"
    setfacl -R -m g:hmi_resourceaccess:rX,g:12201:rwX,g:$u:rwX "$top/rhmiData" 2>/dev/null \
        || setfacl -R -m g:5001:rX,g:12201:rwX,g:$u:rwX "$top/rhmiData" || warn "setfacl failed on rhmiData"
    find "$top/rhmiData" -type d -exec setfacl -d -m g:hmi_resourceaccess:rX,g:12201:rwX,g:$u:rwX {} \; 2>/dev/null \
        || find "$top/rhmiData" -type d -exec setfacl -d -m g:5001:rX,g:12201:rwX,g:$u:rwX {} \;
    # home-screen widget (rhmiDataStartWidget): read by MainApp and the HMI, like rhmiData
    if [ -d "$top/rhmiDataStartWidget" ]; then
        setfacl -R -m g:hmi_resourceaccess:rX,g:12201:rwX,g:$u:rwX "$top/rhmiDataStartWidget" 2>/dev/null \
            || setfacl -R -m g:5001:rX,g:12201:rwX,g:$u:rwX "$top/rhmiDataStartWidget" || warn "setfacl failed on rhmiDataStartWidget"
    fi
}

custom_list() {    # custom_list add|del <id>  - maintain custom_apps.json
    "$NODE" -e '
        const fs = require("fs"), f = process.argv[1], op = process.argv[2], id = process.argv[3];
        let c = {}; try { c = JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) {}
        if (op === "add") c[id] = c[id] || { "-appStartType": "manually", "-userLoginRequired": "false" };
        else delete c[id];
        fs.writeFileSync(f, JSON.stringify(c, null, 2) + "\n");' "$CUSTOM" "$1" "$2" || warn "could not update $CUSTOM"
    chown 12201:12201 "$CUSTOM" 2>/dev/null; chmod 660 "$CUSTOM" 2>/dev/null
}

patch_active() { grep -q " $MAINJS " /proc/mounts; }

patch_mainapp() {
    if patch_active; then say "provisioning hook already active"; else
        command -v md5sum >/dev/null || die "md5sum not found"
        mkdir -p "$PATCH_DIR"
        "$NODE" "$SELF_DIR/mainapp-patch.js" "$MAINJS" "$PATCH_DIR/main.js" || die "patch failed - MainApp left stock"
        "$NODE" --check "$PATCH_DIR/main.js" || die "patched main.js does not parse - MainApp left stock"
        # remember which stock main.js the patch was made from: the boot hook
        # only applies it while the stock file is unchanged (a firmware update
        # brings a new MainApp - an old patched copy must never cover it)
        md5sum "$MAINJS" | cut -d' ' -f1 > "$PATCH_DIR/stock.md5"
        cat > "$PATCH_DIR/apply.sh" <<APPLY
#!/bin/sh
# mgu-custom-apps: bind-mount the patched MainApp main.js (provisioning hook).
# Runs before oapcontroller starts. Skips itself if MainApp was updated.
M=$MAINJS
D=$PATCH_DIR
grep -q " \$M " /proc/mounts && exit 0
[ -f \$D/main.js ] && [ -f \$D/stock.md5 ] || exit 0
if [ "\$(md5sum \$M | cut -d' ' -f1)" = "\$(cat \$D/stock.md5)" ]; then
    mount --bind \$D/main.js \$M
else
    echo "mgu-custom-apps: MainApp changed since the patch was made - hook NOT applied (re-run: mgu-app-install.sh unpatch && patch --persist)" > /dev/kmsg 2>/dev/null
fi
exit 0
APPLY
        chown -R 0:0 "$PATCH_DIR"
        chmod 755 "$PATCH_DIR" "$PATCH_DIR/main.js" "$PATCH_DIR/apply.sh"
        sh "$PATCH_DIR/apply.sh"
        patch_active || die "bind mount failed"
        say "provisioning hook active (bind mount; reboot = stock unless --persist)"
    fi
    if [ "${1:-}" = "--persist" ]; then
        rw=0
        if ! mkdir -p "$(dirname "$DROPIN")" 2>/dev/null || ! touch "$DROPIN" 2>/dev/null; then
            mount -o remount,rw / && rw=1 && mkdir -p "$(dirname "$DROPIN")" || die "cannot write $DROPIN"
        fi
        {
            echo "# added by mgu-app-install.sh - re-applies the custom-app provisioning hook."
            echo "# remove with: sh mgu-app-install.sh unpatch"
            echo "[Service]"
            # oapcontroller runs as tm_12001; "+" runs this step as root (mount needs it), "-" ignores failures
            echo "ExecStartPre=-+/bin/sh $PATCH_DIR/apply.sh"
        } > "$DROPIN"
        sync
        systemctl daemon-reload
        [ "$rw" = 1 ] && mount -o remount,ro / 2>/dev/null
        say "persisted: $DROPIN"
    fi
    CHANGED=1
}

unpatch_mainapp() {
    while patch_active; do umount "$MAINJS" || die "umount $MAINJS failed"; done
    if [ -f "$DROPIN" ]; then
        rw=0
        rm -f "$DROPIN" 2>/dev/null || { mount -o remount,rw / && rw=1 && rm -f "$DROPIN"; }
        systemctl daemon-reload
        [ "$rw" = 1 ] && mount -o remount,ro / 2>/dev/null
    fi
    rm -rf "$PATCH_DIR"
    say "MainApp back to stock"
    CHANGED=1
}

# gen <manifest.json> <uid> <outDir>: BMW's generator; on failure only its error line, not the
# whole minified generator source node prints with it
gen() {
    "$NODE" "$TMP/oapgen/gen.js" "$CATALOG" "$1" "$2" "$3" > "$TMP/gen.log" 2>&1 && return 0
    grep -m 1 '^[A-Za-z]*Error:' "$TMP/gen.log" | cut -c 1-400 >&2 || tail -n 3 "$TMP/gen.log" >&2
    return 1
}

# optional_missing <unpacked dir>: app.json signals marked "_optional" (meta.json "optional")
# that this unit's catalog does not have are taken out of the app's manifest, so BMW's generator
# accepts it; the app then runs without them. Says what is missing and leaves
# source/javascript/kit/missing-interfaces.json, which the app logs when it starts.
# Any other missing interface still makes the generator refuse the app.
optional_missing() {
    "$NODE" -e '
        const fs = require("fs"), [dir, catalog] = process.argv.slice(1);
        const meta = JSON.parse(fs.readFileSync(dir + "/meta.json", "utf8"));
        const opt = meta.optional || {};
        if (!Object.keys(opt).length) process.exit(0);
        const have = JSON.parse(fs.readFileSync(catalog, "utf8")).interfaces || {};
        const mf = dir + "/source/manifest.json", m = JSON.parse(fs.readFileSync(mf, "utf8"));
        const missing = {};
        for (const i of Object.keys(opt)) if (!have[i]) { missing[i] = opt[i]; delete m.proxies[i]; }
        if (!Object.keys(missing).length) process.exit(0);
        fs.writeFileSync(mf, JSON.stringify(m, null, 1));
        fs.writeFileSync(dir + "/source/javascript/kit/missing-interfaces.json", JSON.stringify(missing, null, 1));
        for (const i of Object.keys(missing))
            console.error("[mgu-app] WARNING: " + meta.id + ": this unit has no " + i + " - installed without it: " + missing[i]);
    ' "$1" "$CATALOG"
}

# verify_one <app.mgu>: would install_one's interface generation pass on this unit? Only $TMP is
# written. Returns 1 (with the generator's reason) if not.
verify_one() {
    pkg=$1
    [ -f "$pkg" ] || die "no such file: $pkg"
    rm -rf "$TMP"; mkdir -p "$TMP/out"
    tar xzf "$pkg" -C "$TMP" || die "cannot unpack $pkg"
    [ -f "$TMP/meta.json" ] && [ -f "$TMP/source/manifest.json" ] && [ -f "$TMP/oapgen/gen.js" ] \
        || die "$pkg is not an MGU app bundle"
    id=$("$NODE" -e "process.stdout.write(require('$TMP/meta.json').id)")
    ver=$("$NODE" -e "process.stdout.write(require('$TMP/meta.json').version)")
    optional_missing "$TMP" || die "cannot read $pkg or $CATALOG"
    u=$(uid_of "$id"); [ -n "$u" ] || u=$FIRST_UID
    if gen "$TMP/source/manifest.json" "$u" "$TMP/out"; then
        say "$id $ver: accepted"; rm -rf "$TMP"; return 0
    fi
    echo "[mgu-app] ERROR: $id $ver is refused by this unit (its signals in app.json, see above)" >&2
    rm -rf "$TMP"; return 1
}

install_one() {
    pkg=$1
    [ -f "$pkg" ] || die "no such file: $pkg"
    rm -rf "$TMP"; mkdir -p "$TMP"
    tar xzf "$pkg" -C "$TMP" || die "cannot unpack $pkg"
    [ -f "$TMP/meta.json" ] && [ -d "$TMP/source" ] && [ -d "$TMP/rhmiData" ] || die "$pkg is not an MGU app bundle"
    id=$("$NODE" -e "process.stdout.write(require('$TMP/meta.json').id)")
    ver=$("$NODE" -e "process.stdout.write(require('$TMP/meta.json').version)")
    case "$id" in ''|*[!a-zA-Z0-9_-]*) die "bad app id '$id'";; esac
    optional_missing "$TMP" || die "cannot read $pkg or $CATALOG"

    u=$(uid_of "$id")
    if [ -n "$u" ]; then
        say "updating $id -> $ver (uid $u)"
        is_ours "$id" "$u" || die "$id is a BMW app (uid $u); refusing to overwrite it"
        update=1
    else
        u=$(free_uid) || die "no free uid in $LAST_UID..$FIRST_UID"
        say "installing $id $ver as uid $u"
        update=0
    fi
    top=$OAP/oap_$u

    # a running instance is NOT killed: MainApp counts an unexpected exit as a
    # crash (1st: wipes the app's data, 2nd: uninstalls it). Restart the
    # platform instead, which stops apps the proper way.
    for p in $(pidof node 2>/dev/null); do
        if [ "$(awk '/^Uid/{print $2}' /proc/$p/status 2>/dev/null)" = "$u" ]; then NEED_RESTART=1; fi
    done

    mkdir -p "$top"
    rm -rf "$top/source" "$top/rhmiData" "$top/rhmiDataStartWidget" "$top/someipInterfaces"
    cp -a "$TMP/source" "$top/source" || die "copy source failed"
    cp -a "$TMP/rhmiData" "$top/rhmiData" || die "copy rhmiData failed"
    # optional home-screen widget (app.json "startWidget")
    if [ -d "$TMP/rhmiDataStartWidget" ]; then
        cp -a "$TMP/rhmiDataStartWidget" "$top/rhmiDataStartWidget" || die "copy rhmiDataStartWidget failed"
    fi
    for d in data kvs share security; do mkdir -p "$top/$d"; done
    # native platform modules, linked like the installer does
    mkdir -p "$top/source/node_modules"
    for n in certmgr codings ecu nare_logging necemapaths personalization smrf-native-cpp someip wscpp-client; do
        [ -e "/usr/lib/$n.node" ] && ln -sfn "/usr/lib/$n.node" "$top/source/node_modules/$n.node"
    done
    # someipInterfaces + acl.json with BMW's generator
    mkdir -p "$top/someipInterfaces"
    if ! gen "$top/source/manifest.json" "$u" "$top/someipInterfaces"; then
        [ $update = 0 ] && rm -rf "$top"        # a new app: leave no half-installed folder behind
        die "interface generation failed for $id (see above)"
    fi

    # ownership/modes as on stock installs. data/ kvs/ share/ security/ keep what the app
    # (or the platform) put in them: on an update, chowning their contents to 12201 leaves
    # e.g. data/.joynr unwritable for the app, which then crashes on its first start.
    chown -h 12201:$u "$top" "$top/data" "$top/kvs" "$top/share" "$top/security"
    chown -Rh 12201:$u "$top/source" "$top/someipInterfaces" "$top/rhmiData"
    chmod 750 "$top" "$top/source" "$top/someipInterfaces"
    chmod 770 "$top/data" "$top/kvs" "$top/share" "$top/security" "$top/rhmiData"
    find "$top/source" -type d -exec chmod 750 {} \;
    find "$top/source" -type f -exec chmod 640 {} \;
    find "$top/someipInterfaces" -type f -exec chmod 640 {} \;
    find "$top/rhmiData" -type d -exec chmod 770 {} \;
    find "$top/rhmiData" -type f -exec chmod 660 {} \;
    if [ -d "$top/rhmiDataStartWidget" ]; then
        chown -Rh 12201:$u "$top/rhmiDataStartWidget"
        find "$top/rhmiDataStartWidget" -type d -exec chmod 770 {} \;
        find "$top/rhmiDataStartWidget" -type f -exec chmod 660 {} \;
    fi
    # the app (uid/gid $u) writes data/ (settings, log) and rhmiData/resources
    # (its drawn graphics) through the group bits, like BMW's apps
    set_acls "$top" "$u"

    # register
    if [ $update = 0 ]; then
        NEED_RESTART=1
        ensure_newline "$UIDS"
        echo "$u=$id" >> "$UIDS"
    fi
    # (re)write the registry entry: MainApp resets the flags to false while
    # the provisioning hook is not active, so a reinstall repairs that too
    printf '{"userId":%s,"provisioningCache":{"-allowed":"true","-appStartType":"manually","-enabled":"true","-userLoginRequired":"false","-updateMechanism":"PLATFORM"},"configStateQueueIndex":null,"installationSource":"PREINSTALLED"}' "$u" > "$REG/$id.json"
    chown 12201:12201 "$REG/$id.json"; chmod 660 "$REG/$id.json"
    custom_list add "$id"
    CHANGED=1
    say "installed $id $ver -> $top"
    rm -rf "$TMP"
}

uninstall_check() {    # <id>: dies unless it is installed and ours; sets u
    u=$(uid_of "$1")
    [ -n "$u" ] || die "$1 is not installed"
    is_ours "$1" "$u" || die "$1 is a BMW app (uid $u); this tool only removes apps it installed"
}

uninstall_one() {
    id=$1
    # checked (uninstall_check) before the platform stopped: nothing here may die, the platform must start again
    u=$(uid_of "$id"); [ -n "$u" ] || return 0      # (an id given twice: gone already)
    sed -i "/^$u=$id\$/d" "$UIDS"
    rm -f "$REG/$id.json"
    custom_list del "$id"
    rm -rf "$OAP/oap_$u"
    CHANGED=1
    say "removed $id (uid $u)"
}

list_apps() {
    hook=off; patch_active && hook=active; [ -f "$DROPIN" ] && hook="$hook (persistent)"
    echo "provisioning hook: $hook"
    printf '%-6s %-24s %-10s %-11s %s\n' UID APP VERSION SOURCE STATE
    sed 's/\r//' "$UIDS" | while IFS='=' read -r u id || [ -n "$u" ]; do
        [ -n "$u" ] || continue
        v=$(sed -n 's/.*"version"[^"]*"\([^"]*\)".*/\1/p' "$OAP/oap_$u/source/package.json" 2>/dev/null | head -n 1)
        src=$(sed -n 's/.*"installationSource":"\([A-Z]*\)".*/\1/p' "$REG/$id.json" 2>/dev/null)
        st=stopped
        for p in $(pidof node 2>/dev/null); do
            [ "$(awk '/^Uid/{print $2}' /proc/$p/status 2>/dev/null)" = "$u" ] && st="running(pid $p)"
        done
        [ -d "$OAP/oap_$u" ] || st=MISSING
        printf '%-6s %-24s %-10s %-11s %s\n' "$u" "$id" "${v:--}" "${src:--}" "$st"
    done
}

status_one() {
    id=$1; u=$(uid_of "$id")
    [ -n "$u" ] || die "$id is not installed"
    list_apps | sed -n "1p;/ $id /p"
    echo "--- crash history (MainApp):"
    grep -o "\"name\":\"$id\"[^}]*" "$MAIN/data/diagOapStartStopStatus.json" 2>/dev/null | tail -n 5 || true
    echo "--- app log ($OAP/oap_$u/data/$id.log):"
    tail -n 25 "$OAP/oap_$u/data/$id.log" 2>/dev/null || echo "(none yet - the app writes it once started)"
}

restore() {
    B=${1:-}
    [ -n "$B" ] || B=$(cat "$BACKUP_ROOT/latest" 2>/dev/null)
    [ -n "$B" ] && [ -f "$B/uids.txt" ] || die "no backup found (looked in $BACKUP_ROOT)"
    tar tzf "$B/registry.tgz" >/dev/null || die "$B/registry.tgz is damaged - nothing restored"
    say "restoring registry from $B"
    # remove app dirs that the backup did not know about (installed after it)
    sed 's/\r//' "$UIDS" | while IFS='=' read -r u id || [ -n "$u" ]; do
        [ -n "$u" ] || continue
        if ! grep -q "^$u=$id\$" "$B/uids.txt" && is_ours "$id" "$u"; then
            say "  removing $id (uid $u)"; rm -rf "$OAP/oap_$u"
        fi
    done
    cp -p "$B/uids.txt" "$UIDS"
    rm -rf "$MAIN/data/apps" && tar xzf "$B/registry.tgz" -C "$MAIN/data"
    if [ -f "$B/custom_apps.json" ]; then cp -p "$B/custom_apps.json" "$CUSTOM"; else rm -f "$CUSTOM"; fi
    CHANGED=1
}

renderd_unit() {   # the unit file text
    cat <<UNIT
# added by mgu-app-install.sh - GPU renderer for the custom apps (remove: sh mgu-app-install.sh renderd-remove)
[Unit]
Description=mgu-renderd (GPU renderer for custom apps: mgu-render)
After=winston.service
StartLimitIntervalSec=0

[Service]
# root for the touch divert (nft) and the foreground gate (SOME/IP as root), in the compositor's group
User=root
Group=mgu_wayland
Environment=XDG_RUNTIME_DIR=/run/wayland
RuntimeDirectory=mgu-renderd
RuntimeDirectoryMode=0755
ExecStartPre=/bin/sh -c 'until [ -S /run/wayland/wayland-0 ]; do sleep 1; done'
ExecStart=$RENDERD_DIR/mgu-renderd -s socket_path=/run/mgu-renderd/renderd.sock -s socket_group=$APP_GID -s embed_marker=$EMBED_RUN/hmi-template -s touch_area=84,0,1836,720
# touch_area: apps may claim the title strip too (the kit's page tabs are there); only what an app claims is its
# a stopped renderer leaves no touch divert behind (only its own table)
ExecStopPost=-/bin/sh -c 'nft delete table ip idrive7_render 2>/dev/null; true'
Restart=always
RestartSec=3
TimeoutStartSec=150
TimeoutStopSec=5

[Install]
WantedBy=oapcontroller.service
UNIT
}

rootfs_rw_do() {   # run "$@" with / writable (remounts rw only if it has to)
    if "$@" 2>/dev/null; then return 0; fi
    mount -o remount,rw / || return 1
    "$@"; r=$?
    sync; mount -o remount,ro / 2>/dev/null
    return $r
}

# This repository's renderer installed earlier through mgu-store (tool idrive7-renderd): one of ours is
# enough, two fight over the socket and the controller. Removed through the Store's own deploy tool, so the
# Store knows it is gone (it can be installed from the Store again later: it then takes this one over).
retire_store_renderer() {
    [ -e /var/opt/idrive7-renderd/current ] || [ -e /etc/systemd/system/idrive7-renderd.service ] || return 0
    if [ -f /var/opt/mgu-deploy/mgu-deploy.sh ]; then
        say "removing the renderer installed through the Store (idrive7-renderd): this one replaces it"
        if sh /var/opt/mgu-deploy/mgu-deploy.sh uninstall idrive7-renderd --yes > "$TMP.dep" 2>&1; then
            rm -f "$TMP.dep"; return 0
        fi
        sed 's/^/    /' "$TMP.dep" >&2; rm -f "$TMP.dep"
    fi
    die "the Store's idrive7-renderd is installed and could not be removed: remove it in the Store, then run this again"
}

install_renderd() {
    src=$SELF_DIR/mgu-renderd
    [ -f "$src" ] || die "mgu-renderd not found next to $0"
    retire_store_renderer
    # everything is put in place first and the running renderer is restarted only at the end, in
    # one step (the apps draw in software only for those few seconds); unchanged: not restarted
    same=0; cmp -s "$src" "$RENDERD_DIR/mgu-renderd" 2>/dev/null && same=1
    # a running binary can be replaced by rename: the old process keeps its copy until restarted
    mkdir -p "$RENDERD_DIR" && cp "$src" "$RENDERD_DIR/mgu-renderd.new" && mv "$RENDERD_DIR/mgu-renderd.new" "$RENDERD_DIR/mgu-renderd" || die "copy failed"
    # its script files: the foreground gate it starts (shows an app only while its screen is in front),
    # and the page template's generator and mount script (renderd-embed)
    for f in $RENDERD_FILES; do
        [ -f "$SELF_DIR/$f" ] || continue
        cmp -s "$SELF_DIR/$f" "$RENDERD_DIR/$f" || { [ "$f" = foreground_gate.js ] && same=0; }
        cp "$SELF_DIR/$f" "$RENDERD_DIR/$f" || die "copy failed"
    done
    chown -R 0:0 "$RENDERD_DIR"; chmod 755 "$RENDERD_DIR" "$RENDERD_DIR/mgu-renderd"
    if [ "${1:-}" = "--persist" ]; then
        rm -f "/run/systemd/system/$RENDERD_UNIT"
        renderd_unit > "$TMP.unit" || die "tmp"
        cmp -s "$TMP.unit" "/etc/systemd/system/$RENDERD_UNIT" || same=0
        rootfs_rw_do sh -c "cp '$TMP.unit' '/etc/systemd/system/$RENDERD_UNIT' && mkdir -p /etc/systemd/system/oapcontroller.service.wants && ln -sf '../$RENDERD_UNIT' '/etc/systemd/system/oapcontroller.service.wants/$RENDERD_UNIT'" || die "cannot write /etc/systemd/system/$RENDERD_UNIT"
        rm -f "$TMP.unit"
        for u in $DBR_UNITS; do
            printf '# added by mgu-app-install.sh: mgu-renderd serves display-bridge'"'"'s apps (its socket, the page template)\n[Unit]\nConditionPathExists=!%s/mgu-renderd\n' "$RENDERD_DIR" > "$TMP.dbr"
            cmp -s "$TMP.dbr" "/etc/systemd/system/$u.d/$DBR_DROPIN" || rootfs_rw_do sh -c "mkdir -p '/etc/systemd/system/$u.d' && cp '$TMP.dbr' '/etc/systemd/system/$u.d/$DBR_DROPIN'" || warn "cannot write the $u drop-in"
        done
        rm -f "$TMP.dbr"
        say "renderer persisted (starts with the app platform)"
    else
        # runtime unit: gone after a reboot
        renderd_unit > "/run/systemd/system/$RENDERD_UNIT" || die "cannot write the runtime unit"
        same=0
    fi
    systemctl daemon-reload
    if [ $same = 1 ] && systemctl is-active -q "$RENDERD_UNIT"; then say "renderer unchanged and running"; renderd_embed_too "${1:-}"; return 0; fi
    systemctl restart "$RENDERD_UNIT" || die "renderer did not start: journalctl -u $RENDERD_UNIT"
    i=0; while [ $i -lt 10 ] && [ ! -S /run/mgu-renderd/renderd.sock ]; do sleep 1; i=$((i+1)); done
    if [ -S /run/mgu-renderd/renderd.sock ]; then say "renderer running - apps switch to it within a few seconds"
    else warn "renderer socket not up yet - see: journalctl -u $RENDERD_UNIT"; fi
    renderd_embed_too "${1:-}"
}
# a persistent renderer gets in-page drawing too (NO_EMBED=1: not); without it the renderer works as before
renderd_embed_too() {
    [ "${1:-}" = "--persist" ] && [ "${NO_EMBED:-0}" != 1 ] || return 0
    ( install_embed ) || warn "in-page drawing not set up - apps draw over their pages instead (sh $0 renderd-embed to try again)"
}

remove_renderd() {
    remove_inputgate
    remove_embed
    systemctl stop "$RENDERD_UNIT" 2>/dev/null
    rm -f "/run/systemd/system/$RENDERD_UNIT"
    if [ -e "/etc/systemd/system/$RENDERD_UNIT" ] || [ -L "/etc/systemd/system/oapcontroller.service.wants/$RENDERD_UNIT" ]; then
        rootfs_rw_do sh -c "rm -f '/etc/systemd/system/$RENDERD_UNIT' '/etc/systemd/system/oapcontroller.service.wants/$RENDERD_UNIT' && { rmdir /etc/systemd/system/oapcontroller.service.wants 2>/dev/null; true; }"
    fi
    for u in $DBR_UNITS; do
        [ -e "/etc/systemd/system/$u.d/$DBR_DROPIN" ] && rootfs_rw_do sh -c "rm -f '/etc/systemd/system/$u.d/$DBR_DROPIN' && { rmdir '/etc/systemd/system/$u.d' 2>/dev/null; true; }"
    done
    systemctl daemon-reload
    rm -rf "$RENDERD_DIR"
    say "renderer removed (apps draw in software again)"
}

# ---- in-page drawing: the renderer's HMI page template (kit/renderd/systemd/mgu-render-hmi.sh) ----
# Apps can draw inside their own HMI page instead of over it (mgu-render/1 "embed", display-bridge's apps): the
# HMI's title bar, popups, camera, BACK and HOME then behave as on any stock page. The template is made once here
# from the installed HmiMain3D (in $RENDERD_DIR/hmi); $EMBED_UNIT mounts it into the HMI's widgets before each HMI
# start (a copy in /run, nothing on the unit is written), only while it was made for this HmiMain3D, and behind a
# boot guard (mgu-render-hmi-guard.sh: left out after two starts in a row in which the HMI did not stay up with it).
embed_unit() {
    cat <<UNIT
# added by mgu-app-install.sh - the renderer's page template in the HMI (remove: sh mgu-app-install.sh renderd-embed-remove)
[Unit]
Description=mgu-renderd page template for the HMI (in-page drawing)
DefaultDependencies=no
Before=hmi.service
RequiresMountsFor=$RENDERD_DIR /mnt/dataro/data/hmi
# mgu-store's own mgu-render, when installed, puts its template in instead
ConditionPathExists=!/var/opt/mgu-render/current/mgu-render
# the Store's idrive7-renderd took this renderer over (it removes the program, not this unit): its own unit mounts
ConditionPathExists=$RENDERD_DIR/mgu-renderd

[Service]
Type=oneshot
RemainAfterExit=yes
# mounts the template made at install, nothing more: without one for this HmiMain3D, on any failure, after two
# starts the HMI did not survive with it, or after 30 s, the stock widgets stay and the HMI starts as usual
TimeoutStartSec=30
Environment=MGU_RENDER_RUN=$EMBED_RUN/hmi-widget MGU_RENDER_MARKER=$EMBED_RUN/hmi-template
ExecStart=-/bin/sh $RENDERD_DIR/mgu-render-hmi-guard.sh $RENDERD_DIR $RENDERD_DIR/hmi

[Install]
WantedBy=hmi.service
UNIT
}

embed_mounted() { grep -q " ${EMBED_RUN#/run}/hmi-widget " /proc/self/mountinfo; }

install_embed() {
    [ -x "$RENDERD_DIR/mgu-renderd" ] || die "install the renderer first (sh $0 renderd --persist)"
    [ -e /usr/bin/HmiMain3D ] || die "no HmiMain3D on this unit: no page template"
    for f in hmi_template.js mgu-render-hmi.sh mgu-render-hmi-guard.sh; do
        [ -f "$SELF_DIR/$f" ] || die "$f not found next to $0"
        cp "$SELF_DIR/$f" "$RENDERD_DIR/$f" || die "copy failed"
    done
    say "making the HMI page template for in-page drawing (up to 2 min)..."
    sh "$RENDERD_DIR/mgu-render-hmi.sh" --build "$RENDERD_DIR" "$RENDERD_DIR/hmi"
    grep -q '"template": "ok"' "$RENDERD_DIR/status.json" 2>/dev/null || die "no page template: $(sed -n 's/^"reason": //p' "$RENDERD_DIR/status.json" 2>/dev/null)"
    rm -f "$RENDERD_DIR/hmi/strikes"                    # installing again = a fresh try for the boot guard
    embed_unit > "$TMP.unit" || die "tmp"
    if ! cmp -s "$TMP.unit" "/etc/systemd/system/$EMBED_UNIT" || [ ! -L "/etc/systemd/system/hmi.service.wants/$EMBED_UNIT" ]; then
        rootfs_rw_do sh -c "cp '$TMP.unit' '/etc/systemd/system/$EMBED_UNIT' && mkdir -p /etc/systemd/system/hmi.service.wants && ln -sf '../$EMBED_UNIT' '/etc/systemd/system/hmi.service.wants/$EMBED_UNIT'" || die "cannot write /etc/systemd/system/$EMBED_UNIT"
        systemctl daemon-reload
    fi
    rm -f "$TMP.unit"
    if [ "${1:-}" = "--now" ]; then
        say "restarting the HMI with the template (VM / bench only)..."
        systemctl stop hmi.service; systemctl restart "$EMBED_UNIT"; systemctl start hmi.service
        systemctl restart "$RENDERD_UNIT" 2>/dev/null
    elif [ -f "$EMBED_RUN/hmi-template" ]; then
        say "in-page drawing ready"
    else
        say "in-page drawing set up: from the next head-unit start"
    fi
}

remove_embed() {
    if [ -e "/etc/systemd/system/$EMBED_UNIT" ] || [ -L "/etc/systemd/system/hmi.service.wants/$EMBED_UNIT" ]; then
        rootfs_rw_do sh -c "rm -f '/etc/systemd/system/$EMBED_UNIT' '/etc/systemd/system/hmi.service.wants/$EMBED_UNIT' && { rmdir /etc/systemd/system/hmi.service.wants 2>/dev/null; true; }"
        systemctl daemon-reload
        say "page template taken out: the stock widgets come back at the next head-unit start"
    fi
    if [ "${1:-}" = "--now" ] && embed_mounted; then
        systemctl stop hmi.service; umount /mnt/dataro/data/hmi/bmw/widget; rm -f "$EMBED_RUN/hmi-template"
        systemctl start hmi.service
    fi
    rm -rf "$RENDERD_DIR/hmi" "$RENDERD_DIR/hmi.new" "$RENDERD_DIR/status.json" "$RENDERD_DIR/hmi_template.js" "$RENDERD_DIR/mgu-render-hmi.sh" "$RENDERD_DIR/mgu-render-hmi-guard.sh"
}

# ---- controller gate (kit/renderd/inputgate/mgu-inputgate.cpp) ----
hmi_preload() {   # the HMI's LD_PRELOAD without ours (other drop-ins may preload things too)
    # from the unit files themselves (systemctl show prints values with spaces as [unprintable]);
    # the last assignment wins, as in systemd
    systemctl cat hmi.service --no-pager 2>/dev/null | awk '
        /^# \// { ours = index($0, "mgu-inputgate") > 0; next }
        ours { next }
        /^[ \t]*Environment=/ && index($0, "LD_PRELOAD=") {
            v = substr($0, index($0, "LD_PRELOAD=") + 11)
            q = index(v, "\""); if (q) v = substr(v, 1, q - 1)
            last = v
        }
        END { print last }' | tr ':' ' ' | tr ' ' '\n' | grep -v '^$' | grep -v 'mgu-inputgate' | tr '\n' ' ' | sed 's/ $//'
}
# The gate is never loaded by restarting the HMI on a car: hmi.service stops with SIGABRT, and the
# head unit's crash monitor answers an aborted HMI by rebooting the whole unit (seen on two cars).
# So it is set up to load the next time the head unit starts, guarded at boot:
#   hmi.service.d/zz-mgu-inputgate.conf  EnvironmentFile=-/run/mgu-inputgate.env (+ the guard first)
#   mgu-inputgate-guard.service          before the HMI: copies the LD_PRELOAD line to /run - unless
#                                        the HMI failed to come up healthy with it twice in a row
#   mgu-inputgate-check.service          after the HMI, 2 min later: the HMI is up with the gate -
#                                        the count goes back to 0
# A broken gate thus costs at most two bad starts, then the HMI starts without it by itself.
GATE_GUARD=$RENDERD_DIR/inputgate-guard.sh
GATE_UNIT=mgu-inputgate-guard.service
GATE_CHECK=mgu-inputgate-check.service
gate_guard_text() {
    cat <<'GUARD'
#!/bin/sh
# added by mgu-app-install.sh - boot guard for the controller gate (mgu-inputgate.so in the HMI)
D=/var/opt/mgu-renderd; RUN=/run/mgu-inputgate.env; N=$D/inputgate.strikes; MAX=2
n=$(cat "$N" 2>/dev/null); case "$n" in ''|*[!0-9]*) n=0;; esac
case "${1:-}" in
boot)
    rm -f "$RUN"
    [ -f "$D/inputgate.env" ] && [ -f "$D/mgu-inputgate.so" ] || exit 0
    if [ "$n" -ge $MAX ]; then
        echo "controller gate left out: the HMI did not come up healthy with it $n times in a row (install again to retry)"
        exit 0
    fi
    echo $((n + 1)) > "$N"; sync
    cp "$D/inputgate.env" "$RUN"
    ;;
check)   # (mgu-inputgate-check.service, after the HMI) the HMI has run with the gate for a minute
    sleep 120
    p=$(pidof HmiMain3D 2>/dev/null | cut -d' ' -f1)
    if [ -n "$p" ] && grep -q mgu-inputgate "/proc/$p/maps" 2>/dev/null && systemctl is-active -q hmi.service; then
        up=$(cut -d. -f1 /proc/uptime); st=$(cut -d')' -f2 "/proc/$p/stat" | awk '{print $20}')
        if [ $((up - st / 100)) -ge 60 ]; then echo 0 > "$N"; sync; echo "controller gate: HMI healthy with it"; fi
    fi
    # never exit: the head unit's lifecycle reboots the unit when a service stops
    while :; do sleep 86400; done
    ;;
esac
exit 0
GUARD
}
gate_unit_text() {
    cat <<UNIT
# added by mgu-app-install.sh - decides at boot whether the HMI loads the controller gate
# (remove: sh mgu-app-install.sh inputgate-remove)
[Unit]
Description=mgu controller gate boot guard
DefaultDependencies=no
RequiresMountsFor=$RENDERD_DIR
Before=hmi.service

[Service]
Type=oneshot
# stays "active" after it ran: a service that stops makes the head unit's lifecycle reboot the unit
RemainAfterExit=yes
TimeoutStartSec=10
ExecStart=/bin/sh $GATE_GUARD boot
UNIT
}
gate_check_text() {
    cat <<UNIT
# added by mgu-app-install.sh - the HMI came up healthy with the controller gate: reset the guard
[Unit]
Description=mgu controller gate check
After=hmi.service
RequiresMountsFor=$RENDERD_DIR

[Service]
# runs on after the check (never exits): a service that stops makes the head unit reboot
Type=simple
ExecStart=/bin/sh $GATE_GUARD check
UNIT
}
gate_dropin_text() {
    cat <<UNIT
# added by mgu-app-install.sh - lets a full-screen custom app (Doom) have the iDrive controller:
# while it asks for it (via mgu-renderd), the HMI ignores the knob, press and tilt; buttons and
# touch always work. Loaded only if $GATE_UNIT puts /run/mgu-inputgate.env there.
# Remove: sh mgu-app-install.sh inputgate-remove
[Unit]
Wants=$GATE_UNIT $GATE_CHECK
After=$GATE_UNIT

[Service]
EnvironmentFile=-/run/mgu-inputgate.env
UNIT
}
gate_env_text() {
    other=$(hmi_preload)
    echo "LD_PRELOAD=${other:+$other }$GATE_SO"
}
gate_loaded() {
    p=$(pidof HmiMain3D 2>/dev/null | cut -d' ' -f1)
    [ -n "$p" ] && grep -q mgu-inputgate "/proc/$p/maps" 2>/dev/null
}
gate_state() {    # one line for status
    if gate_loaded; then echo "loaded"
    elif [ -f "/etc/systemd/system/$GATE_DROPIN_NAME" ]; then
        n=$(cat "$RENDERD_DIR/inputgate.strikes" 2>/dev/null || echo 0)
        if [ "${n:-0}" -ge 2 ] 2>/dev/null; then echo "left out by the boot guard (the HMI failed with it) - install again to retry"
        else echo "set up, loads the next time the head unit starts"; fi
    else echo "not installed"; fi
}
hmi_healthy() {   # HMI up for a while with the gate loaded (--now only)
    i=0
    while [ $i -lt 60 ]; do
        p=$(pidof HmiMain3D 2>/dev/null | cut -d' ' -f1)
        if [ -n "$p" ] && grep -q mgu-inputgate "/proc/$p/maps" 2>/dev/null; then
            sleep 15
            p2=$(pidof HmiMain3D 2>/dev/null | cut -d' ' -f1)
            [ "$p2" = "$p" ] && systemctl is-active -q hmi.service && return 0
            return 1
        fi
        sleep 1; i=$((i+1))
    done
    return 1
}
gate_files_remove() {
    rm -f "/run/systemd/system/$GATE_DROPIN_NAME" /run/mgu-inputgate.env
    rmdir /run/systemd/system/hmi.service.d 2>/dev/null
    if [ -e "/etc/systemd/system/$GATE_DROPIN_NAME" ] || [ -e "/etc/systemd/system/$GATE_UNIT" ] || [ -e "/etc/systemd/system/$GATE_CHECK" ]; then
        rootfs_rw_do sh -c "rm -f '/etc/systemd/system/$GATE_DROPIN_NAME' '/etc/systemd/system/$GATE_UNIT' '/etc/systemd/system/$GATE_CHECK' && { rmdir /etc/systemd/system/hmi.service.d 2>/dev/null; true; }"
    fi
    rm -f "$RENDERD_DIR/inputgate.env" "$RENDERD_DIR/inputgate.strikes" "$GATE_GUARD"
    systemctl daemon-reload
}
install_inputgate() {
    now=0; [ "${1:-}" = "--now" ] && now=1      # (--persist: accepted, it always is)
    src=$SELF_DIR/mgu-inputgate.so
    [ -f "$src" ] || die "mgu-inputgate.so not found next to $0"
    [ -d "$RENDERD_DIR" ] || die "install the renderer first (sh $0 renderd)"
    rm -f "/run/systemd/system/$GATE_DROPIN_NAME"      # (older installers tried it from /run)
    cp "$src" "$GATE_SO.new" && chmod 755 "$GATE_SO.new" && chown 0:0 "$GATE_SO.new" && mv "$GATE_SO.new" "$GATE_SO" || die "copy failed"
    # (new file + rename: a running copy keeps reading its own)
    gate_guard_text > "$GATE_GUARD.new" && chmod 755 "$GATE_GUARD.new" && mv "$GATE_GUARD.new" "$GATE_GUARD" || die "cannot write $GATE_GUARD"
    gate_env_text > "$RENDERD_DIR/inputgate.env" || die "cannot write $RENDERD_DIR/inputgate.env"
    echo 0 > "$RENDERD_DIR/inputgate.strikes"          # installing again = a fresh try
    gate_unit_text > "$TMP.unit" && gate_check_text > "$TMP.check" && gate_dropin_text > "$TMP.gate" || die "tmp"
    if ! cmp -s "$TMP.unit" "/etc/systemd/system/$GATE_UNIT" || ! cmp -s "$TMP.check" "/etc/systemd/system/$GATE_CHECK" || ! cmp -s "$TMP.gate" "/etc/systemd/system/$GATE_DROPIN_NAME"; then
        rootfs_rw_do sh -c "cp '$TMP.unit' '/etc/systemd/system/$GATE_UNIT' && cp '$TMP.check' '/etc/systemd/system/$GATE_CHECK' && mkdir -p /etc/systemd/system/hmi.service.d && cp '$TMP.gate' '/etc/systemd/system/$GATE_DROPIN_NAME'" || { rm -f "$TMP.unit" "$TMP.check" "$TMP.gate"; die "cannot write the controller gate's units to /etc/systemd/system"; }
    fi
    rm -f "$TMP.unit" "$TMP.check" "$TMP.gate"
    systemctl daemon-reload
    if [ $now = 0 ]; then
        if gate_loaded; then say "controller gate loaded (the updated copy loads the next time the head unit starts)"
        else say "controller gate set up - it loads the next time the head unit starts (the HMI is not restarted now: on a car that reboots the head unit)"; fi
        return 0
    fi
    # --now (VM / bench only): restart the HMI with it (the guard first), take it out again if
    # the HMI isn't healthy
    systemctl restart "$GATE_UNIT" 2>/dev/null
    say "restarting the HMI with the controller gate (VM / bench: on a car this reboots the head unit)..."
    systemctl restart hmi.service 2>/dev/null || say "(systemctl reported an error stopping the old HMI - normal, it stops with SIGABRT)"
    if ! hmi_healthy; then
        warn "the HMI did not come back healthy with the controller gate - taking it out again"
        gate_files_remove; rm -f "$GATE_SO"
        systemctl reset-failed hmi.service 2>/dev/null
        systemctl restart hmi.service || warn "HMI restart without the gate failed too - reboot the head unit"
        return 1
    fi
    echo 0 > "$RENDERD_DIR/inputgate.strikes"
    say "controller gate loaded - full-screen apps can have the controller"
}
remove_inputgate() {
    had=0; { [ -e "/etc/systemd/system/$GATE_DROPIN_NAME" ] || [ -e "$GATE_SO" ]; } && had=1
    gate_files_remove
    rm -f "$GATE_SO"      # (a running HMI keeps its mapped copy; without the drop-in it is not loaded again)
    [ $had = 1 ] || { say "controller gate not installed"; return 0; }
    if [ "${1:-}" = "--now" ]; then say "restarting the HMI without the controller gate (VM / bench only)..."; systemctl restart hmi.service 2>/dev/null; fi
    say "controller gate removed - the HMI drops it the next time the head unit starts"
}

apply() {
    if [ "${NO_RESTART:-0}" = 1 ]; then say "NO_RESTART=1: run 'systemctl restart oapcontroller' later"; return; fi
    say "restarting the app platform (the HMI app list reloads, ~1-2 min)..."
    systemctl restart oapcontroller.service || warn "restart failed"
}

cmd=${1:-}; [ $# -gt 0 ] && shift
case "$cmd" in
    install)   [ $# -gt 0 ] || die "usage: $0 install <app.mgu>..."
               backup; for f in "$@"; do install_one "$f"; DONE_RESTART=$NEED_RESTART; done
               DONE_RESTART=0
               patch_active || warn "provisioning hook not active: MainApp will hide the app. Run: sh $0 patch"
               if [ $NEED_RESTART = 1 ]; then apply; else say "updated in place - the new version runs on the next tile tap"; fi ;;
    verify)    [ $# -gt 0 ] || die "usage: $0 verify <app.mgu>..."
               bad=0; for f in "$@"; do verify_one "$f" || bad=1; done
               exit $bad ;;
    uninstall) [ $# -gt 0 ] || die "usage: $0 uninstall <app-id>..."
               # every id checked first: an error after the stop below would leave the platform stopped
               for a in "$@"; do uninstall_check "$a"; done
               # stop the platform first so MainApp doesn't see the app vanish
               # under it (it would try to "recover" it)
               backup; [ "${NO_RESTART:-0}" = 1 ] || systemctl stop oapcontroller.service
               for a in "$@"; do uninstall_one "$a"; done
               if [ "${NO_RESTART:-0}" = 1 ]; then apply; else say "starting the app platform..."; systemctl start oapcontroller.service; fi ;;
    list)      list_apps ;;
    status)    status_one "${1:-}" ;;
    restore)   restore "${1:-}"; apply ;;
    apply)     CHANGED=1; apply ;;
    patch)     patch_mainapp "${1:-}"; apply ;;
    unpatch)   unpatch_mainapp; apply ;;
    renderd)   install_renderd "${1:-}" ;;
    renderd-remove) remove_renderd ;;
    renderd-embed) install_embed "${1:-}" ;;
    renderd-embed-remove) remove_embed "${1:-}" ;;
    inputgate) install_inputgate "${1:-}" ;;
    inputgate-remove) remove_inputgate "${1:-}" ;;
    inputgate-status) echo "controller gate: $(gate_state)" ;;
    *) sed -n '2,37p' "$0"; exit 2 ;;
esac
